package com.example.dsandroid2025_xinyeelee.model;

import java.io.Serializable;

public class MarsSol implements Serializable {
    private String id;

    private double tempAvg;
    private double tempMin;
    private double tempMax;

    private double pressureAvg;
    private double pressureMin;
    private double pressureMax;

    public MarsSol(String id, double tempAvg, double tempMin, double tempMax, double pressureAvg, double pressureMin, double pressureMax) {
        this.id = id;
        this.tempAvg = tempAvg;
        this.tempMin = tempMin;
        this.tempMax = tempMax;
        this.pressureAvg = pressureAvg;
        this.pressureMin = pressureMin;
        this.pressureMax = pressureMax;
    }

    public MarsSol() {
    }

    public String getId() {
        return id;
    }

    public double getTempAvg() {
        return tempAvg;
    }

    public double getTempMin() {
        return tempMin;
    }

    public double getTempMax() {
        return tempMax;
    }

    public double getPressureAvg() {
        return pressureAvg;
    }

    public double getPressureMin() {
        return pressureMin;
    }

    public double getPressureMax() {
        return pressureMax;
    }

    private int[] windCounts = new int[16];

    public int[] getWindCounts() {
        return windCounts;
    }

    public void setWindCounts(int[] windCounts) {
        this.windCounts = windCounts;
    }
}
