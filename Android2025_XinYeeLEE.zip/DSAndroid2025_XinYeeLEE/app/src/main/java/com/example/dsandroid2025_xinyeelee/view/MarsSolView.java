package com.example.dsandroid2025_xinyeelee.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class MarsSolView extends View {
    private int[] windData = new int[16];
    private Paint circlePaint;
    private Paint trianglePaint;
    private Paint linePaint;

    public MarsSolView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        circlePaint = new Paint();
        circlePaint.setStyle(Paint.Style.STROKE);
        circlePaint.setColor(Color.WHITE);
        circlePaint.setStrokeWidth(4);
        circlePaint.setAntiAlias(true);

        trianglePaint = new Paint();
        trianglePaint.setStyle(Paint.Style.FILL);
        trianglePaint.setColor(Color.parseColor("#4287f5"));
        trianglePaint.setAntiAlias(true);
        trianglePaint.setAlpha(200);

        linePaint = new Paint();
        linePaint.setColor(Color.GRAY);
        linePaint.setStrokeWidth(2);
    }

    public void setWindData(int[] data) {
        this.windData = data;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int centerX = width / 2;
        int centerY = height / 2;

        float maxRadius = Math.min(centerX, centerY) - 20;

        // 1. Trouver la valeur maximale de vent pour l'échelle
        int maxWindValue = 0;
        for (int val : windData) {
            if (val > maxWindValue) maxWindValue = val;
        }
        if (maxWindValue == 0) maxWindValue = 1;

        // 2. Dessiner le cercle extérieur
        canvas.drawCircle(centerX, centerY, maxRadius, circlePaint);

        // Dessiner une croix pour se repérer
        canvas.drawLine(centerX, centerY - maxRadius, centerX, centerY + maxRadius, linePaint);
        canvas.drawLine(centerX - maxRadius, centerY, centerX + maxRadius, centerY, linePaint);

        // 3. Dessiner les 16 triangles
        canvas.save();
        canvas.translate(centerX, centerY);

        for (int i = 0; i < 16; i++) {
            float value = windData[i];
            float triangleHeight = (value / maxWindValue) * maxRadius;

            float halfBase = 20f;

            Path path = new Path();
            path.moveTo(0, 0); // Pointe au centre
            path.lineTo(-halfBase, -triangleHeight);
            path.lineTo(halfBase, -triangleHeight);
            path.close(); // Retour au centre

            canvas.drawPath(path, trianglePaint);

            canvas.rotate(360f / 16f);
        }

        canvas.restore();
    }
}
