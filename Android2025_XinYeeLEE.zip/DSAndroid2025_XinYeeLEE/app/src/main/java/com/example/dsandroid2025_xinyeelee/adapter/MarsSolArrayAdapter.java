package com.example.dsandroid2025_xinyeelee.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.dsandroid2025_xinyeelee.R;
import com.example.dsandroid2025_xinyeelee.model.MarsSol;

import java.util.List;

public class MarsSolArrayAdapter extends ArrayAdapter<MarsSol> {
    private List<MarsSol> data;
    private LayoutInflater inflater;

    public MarsSolArrayAdapter(Context context, List<MarsSol> data) {
        super(context, -1, data);
        this.data = data;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View lineView = inflater.inflate(R.layout.mars_sol_listview_line, parent, false);

        MarsSol currentSol = getItem(position);

        TextView tvId = lineView.findViewById(R.id.tvSolId);
        TextView tvTemp = lineView.findViewById(R.id.tvSolTemp);
        TextView tvPressure = lineView.findViewById(R.id.tvSolPressure);

        if (currentSol != null) {
            tvId.setText("Sol n°" + currentSol.getId());
            tvTemp.setText("Température : " + currentSol.getTempAvg());
            tvPressure.setText("Pression : " + currentSol.getPressureAvg());
        }
        return lineView;
    }
}
