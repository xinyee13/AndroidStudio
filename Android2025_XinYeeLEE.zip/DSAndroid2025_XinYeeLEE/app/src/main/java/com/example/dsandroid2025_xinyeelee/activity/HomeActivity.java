package com.example.dsandroid2025_xinyeelee.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.dsandroid2025_xinyeelee.R;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import com.example.dsandroid2025_xinyeelee.model.MarsSol;
import com.example.dsandroid2025_xinyeelee.adapter.MarsSolArrayAdapter;

public class HomeActivity extends AppCompatActivity {

    private final String API_LIST_URL = "https://api.nasa.gov/insight_weather/?api_key=%s&feedtype=json&ver=1.0";
    private static final String API_TOKEN = "lyhjayVVgcTWkNmFbuQNuKu5hq4nKf3zJw939lvh";
    public static RequestQueue volleyQueue;

    private List<MarsSol> marsSols = new ArrayList<>();

    private ListView lvMarsSol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvMarsSol = findViewById(R.id.lvMarsSol);

        volleyQueue = Volley.newRequestQueue(getApplicationContext());
        loadWeatherList();
    }

    private void loadWeatherList() {
        String url = String.format(API_LIST_URL, API_TOKEN);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            marsSols.clear();
                            JSONArray solKeys = jsonObject.getJSONArray("sol_keys");
                            for (int i = 0; i < solKeys.length(); i++) {
                                String id = solKeys.getString(i);
                                JSONObject solData = jsonObject.getJSONObject(id);
                                double tAvg = 0, tMin = 0, tMax = 0;
                                double pAvg = 0, pMin = 0, pMax = 0;
                                if (solData.has("AT")) {
                                    JSONObject at = solData.getJSONObject("AT");
                                    tAvg = at.optDouble("av", 0.0);
                                    tMin = at.optDouble("mn", 0.0);
                                    tMax = at.optDouble("mx", 0.0);
                                }
                                if (solData.has("PRE")) {
                                    JSONObject pre = solData.getJSONObject("PRE");
                                    pAvg = pre.optDouble("av", 0.0);
                                    pMin = pre.optDouble("mn", 0.0);
                                    pMax = pre.optDouble("mx", 0.0);
                                }
                                int[] windCounts = new int[16];
                                if (solData.has("WD")) {
                                    JSONObject wd = solData.getJSONObject("WD");
                                    for (int j = 0; j < 16; j++) {
                                        String key = String.valueOf(j);
                                        if (wd.has(key)) {
                                            windCounts[j] = wd.getJSONObject(key).optInt("ct", 0);
                                        } else {
                                            windCounts[j] = 0;
                                        }
                                    }
                                }
                                MarsSol marsSol = new MarsSol(id, tAvg, tMin, tMax, pAvg, pMin, pMax);
                                marsSol.setWindCounts(windCounts);
                                marsSols.add(marsSol);
                            }
                            MarsSolArrayAdapter adapter = new MarsSolArrayAdapter(HomeActivity.this, marsSols);
                            lvMarsSol.setAdapter(adapter);
                            lvMarsSol.setOnItemClickListener((parent, view, position, id) -> {
                                MarsSol selectedSol = marsSols.get(position);
                                Intent intent = new Intent(HomeActivity.this, DetailActivity.class);
                                intent.putExtra("extra_mars_sol", selectedSol);
                                startActivity(intent);
                            });
                            Toast.makeText(HomeActivity.this, "NB SOLS : " + marsSols.size(), Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        Toast.makeText(HomeActivity.this, "Error : " + volleyError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );
        volleyQueue.add(jsonObjectRequest);
    }
}