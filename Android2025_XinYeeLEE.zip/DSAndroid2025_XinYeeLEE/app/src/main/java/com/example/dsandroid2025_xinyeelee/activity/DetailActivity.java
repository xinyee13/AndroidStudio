package com.example.dsandroid2025_xinyeelee.activity;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dsandroid2025_xinyeelee.R;
import com.example.dsandroid2025_xinyeelee.model.MarsSol;
import com.example.dsandroid2025_xinyeelee.view.MarsSolView;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        MarsSol sol = (MarsSol) getIntent().getSerializableExtra("extra_mars_sol");

        TextView tvTitle = findViewById(R.id.tvDetailTitle);
        TextView tvTemp = findViewById(R.id.tvDetailTemp);
        TextView tvPressure = findViewById(R.id.tvDetailPressure);

        if (sol != null) {
            tvTitle.setText("Sol n°" + sol.getId());

            String tempText = String.format("Température :\navg: %.2f  min: %.2f  max: %.2f", sol.getTempAvg(), sol.getTempMin(), sol.getTempMax());
            tvTemp.setText(tempText);

            String pressureText = String.format("Pression :\navg: %.2f  min: %.2f  max: %.2f", sol.getPressureAvg(), sol.getPressureMin(), sol.getPressureMax());
            tvPressure.setText(pressureText);
        }

        MarsSolView marsSolView = findViewById(R.id.marsSolView);
        if (sol != null && sol.getWindCounts() != null) {
            marsSolView.setWindData(sol.getWindCounts());
        }
    }
}
